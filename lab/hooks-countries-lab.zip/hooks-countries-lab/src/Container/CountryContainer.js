import { useState, useEffect } from "react";

const CountriesList = () => {

    const [countries, setCountries] = useState([]);
  
    useEffect(
      () => {
        fetch(`https://restcountries.com/v3.1/all`)
        .then(response => response.json())
        .then(result => setCountries(result))
      }, []
    )
  

    // const updateVisitedCountries = ({addNewCountriesVisitedButton})=>{

        // const [countries, setCountries] = useState("");

        const handleFormSubmit = (event) => {event.preventDefault(); 
        
            // const updateVisitedCountries = {countries: countries}


            // addNewCountriesVisitedButton(updateVisitedCountries)

     console.log("added new country")


     }
    return (
      <>
         
         <form action="" id="country-pick" onClick={handleFormSubmit} >
          <label htmlFor="country-selection">Select A Country</label>
          <select name="">
            {countries.map((countries, index) => (
            <option key={index}>
              {countries.name.common}
            </option>))}
          </select>
          <input type="submit" value="Mark as visited"  onChange={(event) => setCountries(event.target.value)} ></input>
          
          </form>
        </>
      
   
    )
  
  
            }
  
  export default CountriesList;