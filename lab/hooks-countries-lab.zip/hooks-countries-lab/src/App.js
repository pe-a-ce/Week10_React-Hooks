
import './App.css';
import { useEffect, useState } from 'react';
import CountriesList from './Container/CountryContainer';
import backgroundimage from './Components/images/backgroundimg.jpg'





function App() {


  return (
    <>
   
    <h1>Keep track of where you have visited!</h1>
    <hr></hr>
    <CountriesList className="dropdown"/>
    <hr></hr>
    <h2>List of the countries you have visited:</h2>
    
    </>
  );
}

   

export default App;



// to do: create components and move things around, seperate cont needs o be created, add handleFormSubmit for submit to list visited countries